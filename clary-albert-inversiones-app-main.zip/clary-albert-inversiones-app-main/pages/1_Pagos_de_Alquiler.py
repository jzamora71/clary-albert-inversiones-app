import streamlit as st
import db
from utils import COMPANY_NAME, money

st.set_page_config(
    page_title=f"{COMPANY_NAME} - Pagos de Alquiler",
    page_icon="🏠",
    layout="centered",
)

st.title("Pagos de Alquiler")

st.markdown(
    "Registre aquí los pagos mensuales de los 13 apartamentos. "
    "Cada registro incluye fecha, número de apartamento, nombre del inquilino y monto."
)

st.divider()

with st.form("nuevo_pago"):
    col1, col2 = st.columns(2)
    with col1:
        fecha = st.date_input("Fecha del pago")
        apartamento = st.selectbox("Apartamento", list(range(1, 14)))
    with col2:
        # Auto‑fill: use last inquilino for this apartment if available
        default_inquilino = ""
        ingresos_existentes = db.get_ingresos()
        for item in ingresos_existentes:
            if item["apartamento"] == int(apartamento):
                default_inquilino = item["inquilino"]
        # Auto‑fill: use last inquilino for this apartment if available
default_inquilino = ""
ingresos_existentes = db.get_ingresos()
for item in ingresos_existentes:
    if item["apartamento"] == int(apartamento):
        default_inquilino = item["inquilino"]

inquilino = st.text_input("Nombre del inquilino", value=default_inquilino)
, value=default_inquilino)
monto = st.number_input(
            "Monto pagado (RD$)",
            min_value=0.0,
            step=100.0,
            format="%.2f",
        )


    submitted = st.form_submit_button("Registrar pago")

    if submitted:
        if not inquilino or monto <= 0:
            st.error("Complete el nombre del inquilino y un monto mayor a cero.")
        else:
            db.add_ingreso(str(fecha), int(apartamento), inquilino, float(monto))
            st.success("Pago registrado correctamente.")

st.divider()
st.subheader("Pagos registrados")

ingresos = db.get_ingresos()
if not ingresos:
    st.info("Todavía no hay pagos registrados.")
else:
    for item in ingresos:
        cols = st.columns([2, 2, 3, 2, 2])
        cols[0].write(item["fecha"])
        cols[1].write(f"Apto {item['apartamento']}")
        cols[2].write(item["inquilino"])
        cols[3].write(money(item["monto"]))
        if cols[4].button("Eliminar", key=f"del_ing_{item['id']}"):
            db.delete_ingreso(item["id"])
            st.experimental_rerun()
