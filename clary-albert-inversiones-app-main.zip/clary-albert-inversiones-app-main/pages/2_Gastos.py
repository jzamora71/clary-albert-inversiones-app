import streamlit as st
import db
from utils import COMPANY_NAME, money

st.set_page_config(
    page_title=f"{COMPANY_NAME} - Gastos",
    page_icon="📤",
    layout="centered",
)

st.title("Gastos")

st.markdown(
    "Registre aquí los gastos relacionados con la operación del edificio "
    "(electricidad, mantenimiento, servicios, etc.)."
)

st.divider()

with st.form("nuevo_gasto"):
    col1, col2 = st.columns(2)
    with col1:
        fecha = st.date_input("Fecha del gasto")
        descripcion = st.text_input("Descripción del gasto")
    with col2:
        monto = st.number_input(
            "Monto del gasto (RD$)",
            min_value=0.0,
            step=100.0,
            format="%.2f",
        )

    submitted = st.form_submit_button("Registrar gasto")

    if submitted:
        if not descripcion or monto <= 0:
            st.error("Complete la descripción y un monto mayor a cero.")
        else:
            db.add_gasto(str(fecha), descripcion, float(monto))
            st.success("Gasto registrado correctamente.")

st.divider()
st.subheader("Gastos registrados")

gastos = db.get_gastos()
if not gastos:
    st.info("Todavía no hay gastos registrados.")
else:
    for item in gastos:
        cols = st.columns([2, 4, 2, 2])
        cols[0].write(item["fecha"])
        cols[1].write(item["descripcion"])
        cols[2].write(money(item["monto"]))
        if cols[3].button("Eliminar", key=f"del_gasto_{item['id']}"):
            db.delete_gasto(item["id"])
            st.experimental_rerun()
