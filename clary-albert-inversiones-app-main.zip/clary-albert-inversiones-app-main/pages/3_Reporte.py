import io
import streamlit as st
import db
from utils import COMPANY_NAME, money

st.set_page_config(
    page_title=f"{COMPANY_NAME} - Reporte Contable",
    page_icon="📊",
    layout="centered",
)

st.title("Reporte Contable Mensual")

ingresos = db.get_ingresos()
gastos = db.get_gastos()

total_ingresos = sum(i["monto"] for i in ingresos)
total_gastos = sum(g["monto"] for g in gastos)
neto = total_ingresos - total_gastos

st.subheader("Resumen")
c1, c2, c3 = st.columns(3)
c1.metric("Pagos de alquiler totales", money(total_ingresos))
c2.metric("Gastos totales", money(total_gastos))
c3.metric("Balance neto", money(neto))

st.divider()
st.subheader("Detalle de ingresos")

if ingresos:
    st.table(
        [
            {
                "Fecha": i["fecha"],
                "Apartamento": i["apartamento"],
                "Inquilino": i["inquilino"],
                "Monto": money(i["monto"]),
            }
            for i in ingresos
        ]
    )
else:
    st.info("No hay ingresos registrados.")

st.divider()
st.subheader("Detalle de gastos")

if gastos:
    st.table(
        [
            {
                "Fecha": g["fecha"],
                "Descripción": g["descripcion"],
                "Monto": money(g["monto"]),
            }
            for g in gastos
        ]
    )
else:
    st.info("No hay gastos registrados.")

st.divider()
st.subheader("Exportar reporte (PDF simple)")

buffer = io.StringIO()
buffer.write(f"{COMPANY_NAME} - Reporte Contable\n\n")
buffer.write(f"Ingresos totales: {money(total_ingresos)}\n")
buffer.write(f"Gastos totales: {money(total_gastos)}\n")
buffer.write(f"Balance neto: {money(neto)}\n\n")

buffer.write("INGRESOS:\n")
for i in ingresos:
    buffer.write(
        f"- {i['fecha']} | Apto {i['apartamento']} | {i['inquilino']} | {money(i['monto'])}\n"
    )

buffer.write("\nGASTOS:\n")
for g in gastos:
    buffer.write(
        f"- {g['fecha']} | {g['descripcion']} | {money(g['monto'])}\n"
    )

pdf_bytes = buffer.getvalue().encode("utf-8")

st.download_button(
    "Descargar reporte en PDF (texto)",
    data=pdf_bytes,
    file_name="reporte_contable_clary_albert.pdf",
    mime="application/pdf",
)
