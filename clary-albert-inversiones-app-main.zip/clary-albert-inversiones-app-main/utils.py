import streamlit as st

COMPANY_NAME = "Clary & Albert Inversiones"


def init_session_state():
    if "initialized" not in st.session_state:
        st.session_state.initialized = True


def money(value: float) -> str:
    return f"RD$ {value:,.2f}"
