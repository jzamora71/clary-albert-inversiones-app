import streamlit as st
import db
from utils import COMPANY_NAME, init_session_state, money

st.set_page_config(
    page_title=f"{COMPANY_NAME} - Contabilidad",
    page_icon="🏢",
    layout="centered",
    initial_sidebar_state="expanded",
)

# --- Estado de sesión + base de datos -------------------------------------
init_session_state()
db.init_db()

# --- Estilos ---------------------------------------------------------------
st.markdown(
    """
    <style>
    .stApp { background-color: #eaf4fb; }
    .main-header { text-align: center; padding: 10px 0 4px 0; }
    .main-header h1 { color: #1f4e79; font-size: 40px; margin-bottom: 0; }
    .main-header p { color: #34608f; font-size: 18px; margin-top: 6px; }
    div[data-testid="stMetric"] {
        background-color: #ffffff;
        border: 1px solid #cfe3f5;
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0px 2px 6px rgba(31, 78, 121, 0.08);
    }
    .stButton>button {
        background-color: #1f4e79;
        color: #ffffff;
        border-radius: 8px;
        padding: 0.6em 1em;
        font-weight: 600;
        border: none;
    }
    .stButton>button:hover {
        background-color: #163a5c;
        color: #ffffff;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# --- Logo + encabezado -----------------------------------------------------
logo_col1, logo_col2, logo_col3 = st.columns([1, 2, 1])
with logo_col2:
    st.image("assets/logo.png", width=260)

st.markdown(
    f"""
    <div class="main-header">
        <h1>{COMPANY_NAME}</h1>
        <p>Panel de Contabilidad</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# --- Texto de bienvenida ---------------------------------------------------
st.markdown(
    """
    <p style="text-align:center; color:#475569; font-size:16px; max-width:520px; margin:0 auto 24px auto;">
        Bienvenidos. Desde aquí pueden registrar los pagos de alquiler de los
        13 apartamentos, ingresar gastos y generar el reporte contable en PDF.
        Utilicen los botones inferiores o el menú lateral para navegar.
    </p>
    """,
    unsafe_allow_html=True,
)

# --- Resumen rápido --------------------------------------------------------
total_ingresos = sum(item["monto"] for item in db.get_ingresos())
total_gastos = sum(item["monto"] for item in db.get_gastos())
neto = total_ingresos - total_gastos

c1, c2, c3 = st.columns(3)
c1.metric("Pagos de alquiler totales", money(total_ingresos))
c2.metric("Gastos totales", money(total_gastos))
c3.metric("Balance neto", money(neto))

st.divider()

# --- Botones de navegación -------------------------------------------------
nav_col1, nav_col2, nav_col3 = st.columns(3)

with nav_col1:
    if st.button("🏠 Ver Pagos de Alquiler", use_container_width=True):
        st.switch_page("pages/1_Pagos_de_Alquiler.py")

with nav_col2:
    if st.button("📤 Ver Gastos", use_container_width=True):
        st.switch_page("pages/2_Gastos.py")

with nav_col3:
    if st.button("📊 Ver Reporte", use_container_width=True):
        st.switch_page("pages/3_Reporte.py")

st.caption(
    "También pueden usar el menú de navegación en la barra lateral izquierda "
    "para ir directamente a Pagos de Alquiler, Gastos o Reporte."
)

# --- Estado del almacenamiento --------------------------------------------
if db.using_supabase():
    st.caption("Almacenamiento permanente activo (Supabase). Los datos no se perderán.")
else:
    st.caption(
        "Almacenamiento temporal (modo de prueba local). Configuren Supabase "
        "en Streamlit Secrets para guardar los datos de forma permanente — ver README.md."
    )
